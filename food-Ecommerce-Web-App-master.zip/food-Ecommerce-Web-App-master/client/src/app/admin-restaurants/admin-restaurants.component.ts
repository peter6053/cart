import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-restaurants',
  templateUrl: './admin-restaurants.component.html',
  styleUrls: ['./admin-restaurants.component.css']
})
export class AdminRestaurantsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
