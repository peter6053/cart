import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drinks-categories',
  templateUrl: './drinks-categories.component.html',
  styleUrls: ['./drinks-categories.component.css']
})
export class DrinksCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
