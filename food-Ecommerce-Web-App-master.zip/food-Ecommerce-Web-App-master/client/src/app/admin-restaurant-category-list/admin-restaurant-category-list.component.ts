import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-restaurant-category-list',
  templateUrl: './admin-restaurant-category-list.component.html',
  styleUrls: ['./admin-restaurant-category-list.component.css']
})
export class AdminRestaurantCategoryListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
