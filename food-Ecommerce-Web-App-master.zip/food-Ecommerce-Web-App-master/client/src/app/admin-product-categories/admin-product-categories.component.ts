import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-product-categories',
  templateUrl: './admin-product-categories.component.html',
  styleUrls: ['./admin-product-categories.component.css']
})
export class AdminProductCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
