import { SearchByPipe } from './search-by.pipe';

describe('SearchByPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByPipe();
    expect(pipe).toBeTruthy();
  });
});
