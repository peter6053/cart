import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drinks-page',
  templateUrl: './drinks-page.component.html',
  styleUrls: ['./drinks-page.component.css']
})
export class DrinksPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
