import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topnavc',
  templateUrl: './topnavc.component.html',
  styleUrls: ['./topnavc.component.css']
})
export class TopnavcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
