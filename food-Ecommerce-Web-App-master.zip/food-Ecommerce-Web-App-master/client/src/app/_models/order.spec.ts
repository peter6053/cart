import { OrderModelServer } from './order';

describe('Order', () => {
  it('should create an instance', () => {
    expect(new OrderModelServer()).toBeTruthy();
  });
});
