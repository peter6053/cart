import { Categories } from './categories';

describe('Categories', () => {
  it('should create an instance', () => {
    expect(new Categories()).toBeTruthy();
  });
});
