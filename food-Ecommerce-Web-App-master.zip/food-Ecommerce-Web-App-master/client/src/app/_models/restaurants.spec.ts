import { SupplierModelServer } from './restaurants';

describe('SupplierModelServer', () => {
  it('should create an instance', () => {
    expect(new SupplierModelServer()).toBeTruthy();
  });
});
