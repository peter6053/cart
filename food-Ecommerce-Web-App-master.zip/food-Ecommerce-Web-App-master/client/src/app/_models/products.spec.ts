import { ProductModelServer } from './products';

describe('Products', () => {
  it('should create an instance', () => {
    expect(new ProductModelServer()).toBeTruthy();
  });
});
