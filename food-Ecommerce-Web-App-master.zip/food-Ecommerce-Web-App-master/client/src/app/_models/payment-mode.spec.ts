import { PaymentMode } from './payment-mode';

describe('PaymentMode', () => {
  it('should create an instance', () => {
    expect(new PaymentMode()).toBeTruthy();
  });
});
