export const environment = {
  production: true,

  firebaseConfig : {
    apiKey: "AIzaSyDvDkNC2S0d4-FN1mW-APLgwDGQCC71dR4",
    authDomain: "maunganoapp.firebaseapp.com",
    projectId: "maunganoapp",
    storageBucket: "maunganoapp.appspot.com",
    messagingSenderId: "574815464711",
    appId: "1:574815464711:web:4b7a60c744057eed68e9a2",
    measurementId: "G-KWXRKGG6RT"
  }
};
